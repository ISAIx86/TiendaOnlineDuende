-- // FILENAME: Pruebas.sql

select * from usuarios where `fecha_elim` is null;